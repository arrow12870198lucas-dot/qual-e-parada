package com.qual_e.parada;

import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.webkit.*;import android.widget.*;import android.graphics.Color;import java.io.*;import java.util.*;

public class MainActivity extends Activity {
  WebView web; ValueCallback<Uri[]> fileCallback; static final int FILE_PICK=42;
  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(15,20,27));
    web=new WebView(this); web.setBackgroundColor(Color.rgb(15,20,27));
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
    web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){ if(fileCallback!=null)fileCallback.onReceiveValue(null); fileCallback=cb; Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/vnd.ms-excel","text/csv","text/comma-separated-values"}); startActivityForResult(i,FILE_PICK); return true; }});
    web.addJavascriptInterface(new AndroidBridge(),"Android"); setContentView(web); web.loadUrl("file:///android_asset/index.html"); }
  @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r==FILE_PICK&&fileCallback!=null){Uri[] out=(c==RESULT_OK&&d!=null&&d.getData()!=null)?new Uri[]{d.getData()}:null; fileCallback.onReceiveValue(out);fileCallback=null;}}
  @Override public void onBackPressed(){ if(web!=null&&web.canGoBack()) web.goBack(); else super.onBackPressed(); }
  class AndroidBridge {
    @JavascriptInterface public void saveDocument(String name,String mime,String dataUri){
      try{String b64=dataUri.substring(dataUri.indexOf(',')+1);byte[] data=android.util.Base64.decode(b64,android.util.Base64.DEFAULT);String fn=(name==null||name.isEmpty())?"arquivo":name;File dir=getExternalFilesDir(null);File f=new File(dir,fn);FileOutputStream os=new FileOutputStream(f);os.write(data);os.close();runOnUiThread(()->Toast.makeText(MainActivity.this,"Arquivo salvo em: "+f.getAbsolutePath(),Toast.LENGTH_LONG).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Erro ao salvar arquivo",Toast.LENGTH_LONG).show());}
    }
    @JavascriptInterface public void saveAppData(String json){
      try{File f=new File(getFilesDir(),"qual_e_parada_data_v1.json");FileOutputStream os=new FileOutputStream(f);os.write((json==null?"":json).getBytes("UTF-8"));os.close();}catch(Exception e){}
    }
    @JavascriptInterface public String loadAppData(){
      try{File f=new File(getFilesDir(),"qual_e_parada_data_v1.json");if(!f.exists())return "";ByteArrayOutputStream out=new ByteArrayOutputStream();FileInputStream in=new FileInputStream(f);byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();return out.toString("UTF-8");}catch(Exception e){return "";}
    }
  }
}
